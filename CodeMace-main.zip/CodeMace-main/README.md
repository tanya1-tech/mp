# CodeMace - All-in-One Coding Portfolio

CodeMace is a comprehensive platform for tracking your coding journey, managing coding sheets, and monitoring coding contests all in one place. This frontend application is built with Next.js and Tailwind CSS.

## Features

- **User Interface**: Sign up, sign in with email/password or Google
- **Profile Tracker**: Track your coding progress across multiple platforms
- **Question Tracker**: Organize and follow popular coding sheets
- **Contest Tracker**: Stay updated with upcoming coding contests
- **Responsive Design**: Mobile-friendly interface that works on all devices

## Tech Stack

- Next.js 14 (App Router)
- React
- Tailwind CSS
- shadcn/ui components

## Getting Started

### Prerequisites

- Node.js 18.x or higher

### Installation

1. Clone the repository
   \`\`\`bash
   git clone https://github.com/yourusername/codemace.git
   cd codemace
   \`\`\`

2. Install dependencies
   \`\`\`bash
   npm install
   \`\`\`

3. Run the development server
   \`\`\`bash
   npm run dev
   \`\`\`

4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Project Structure

\`\`\`
codemace/
├── app/ # Next.js App Router
│ ├── profile-tracker/ # Profile tracker pages
│ ├── question-tracker/ # Question tracker pages
│ ├── event-tracker/ # Event tracker pages
│ ├── sheets/ # Coding sheets pages
│ └── sign-in/ # Authentication pages
├── components/ # React components
├── public/ # Static assets
└── ...
\`\`\`

## Deployment

This project can be deployed on Vercel:

1. Push your code to a GitHub repository
2. Import the repository to Vercel
3. Deploy

## License

This project is licensed under the MIT License - see the LICENSE file for details.
